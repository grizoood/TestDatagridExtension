﻿namespace DataGridExtensionsSample.Infrastructure
{
    class RegionId
    {
        public const string Shell = "Shell";
        public const string Main = "Main";
    }
}
